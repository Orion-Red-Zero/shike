#!/usr/bin/env python3
"""Static source checks for the recovered Shike 1.0.1 project."""
from pathlib import Path
from html.parser import HTMLParser
import json
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / 'project/app/src/main'
HTML = MAIN / 'assets/index.html'


class Audit(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.screens = []
        self.meals = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if values.get('id'):
            self.ids.append(values['id'])
        if values.get('data-screen'):
            self.screens.append(values['data-screen'])
        if values.get('data-meal'):
            self.meals.append(values['data-meal'])


def main():
    html = HTML.read_text(encoding='utf-8')
    manifest = (MAIN / 'AndroidManifest.xml').read_text(encoding='utf-8')
    strings = (MAIN / 'res/values/strings.xml').read_text(encoding='utf-8')
    java = (MAIN / 'java/app/shike/diet/fixed/MainActivity.java').read_text(encoding='utf-8')
    pwa = json.loads((MAIN / 'assets/manifest.json').read_text(encoding='utf-8'))
    sw = (MAIN / 'assets/sw.js').read_text(encoding='utf-8')
    assert 'android:versionCode="2"' in manifest
    assert 'android:versionName="1.0.1"' in manifest
    assert 'package="app.shike.diet.fixed"' in manifest
    assert '<string name="app_name">食刻修复版</string>' in strings
    assert '食刻修复版 1.0.1' in java
    assert '食刻 1.1.0' not in java and '食刻 1.2.0' not in java
    assert '食刻 Android 1.0.1 修复版' in html
    assert '食刻 Android 1.1.0' not in html and '食刻 Android 1.2.0' not in html
    assert 'shike-food-energy-ledger-v1' in html
    assert 'window.SHIKE_NATIVE_ANDROID = true' in html
    assert 'window.__shikeBootOK = true' in html
    assert 'ShikeAndroid.saveTextFile' in html
    assert pwa['short_name'] == '食刻'
    # The original 1.0.1 APK retained this earlier PWA cache name. Preserve it.
    assert "const VERSION = 'shike-v1.0.0';" in sw
    page = Audit()
    page.feed(html)
    duplicates = sorted({value for value in page.ids if page.ids.count(value) > 1})
    assert not duplicates, duplicates
    assert set(page.screens) == {'today', 'add', 'trend', 'me'}, page.screens
    assert set(page.meals) == {'早餐', '午餐', '晚餐', '加餐'}, page.meals
    for target in ['food-notes', 'parse-btn', 'export-csv', 'export-json']:
        assert target in page.ids, target
    # The confirmation button is rendered by renderReview(), not present in
    # the initial static DOM. Check its exact template and event handler.
    for token in ['id="confirm-btn"', 'function renderReview()', 'function confirmReview()']:
        assert token in html, token
    scripts = [s for s in re.findall(r'<script[^>]*>([\s\S]*?)</script>', html) if s.strip()]
    assert scripts
    with tempfile.TemporaryDirectory(prefix='shike-1.0.1-jscheck-') as directory:
        for index, script in enumerate(scripts):
            path = Path(directory) / f'{index:02d}.js'
            path.write_text(script, encoding='utf-8')
            subprocess.run(['node', '--check', str(path)], check=True)
        sw_path = Path(directory) / 'sw.js'
        sw_path.write_text(sw, encoding='utf-8')
        subprocess.run(['node', '--check', str(sw_path)], check=True)
    subprocess.run(['bash', '-n', str(ROOT / 'scripts/build_apk.sh')], check=True)
    assets = sorted(path for path in (MAIN / 'assets').rglob('*') if path.is_file())
    assert len(assets) == 7, len(assets)
    report = {
        'status': 'PASS',
        'application': '食刻修复版',
        'versionName': '1.0.1',
        'versionCode': 2,
        'package': 'app.shike.diet.fixed',
        'dom_ids': len(page.ids),
        'duplicate_ids': duplicates,
        'navigation': page.screens,
        'meals': page.meals,
        'inline_scripts_syntax_checked': len(scripts),
        'service_worker_syntax': 'PASS',
        'asset_count': len(assets),
        'build_script_bash_syntax': 'PASS'
    }
    output = ROOT / 'tests/output/check-source.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
