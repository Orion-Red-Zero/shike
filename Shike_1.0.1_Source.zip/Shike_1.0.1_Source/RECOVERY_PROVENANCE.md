# 1.0.1 源码恢复依据

本包用于交付「食刻修复版 1.0.1」源代码，依据如下：

- 原始安装包：`shike-android-1.0.1-fixed.apk`
- 包名：`app.shike.diet.fixed`
- 版本：`versionName=1.0.1`，`versionCode=2`
- 应用名：`食刻修复版`
- 原 APK SHA-256：`4a4887e523f59771a5c20c179f008c06b77b7449fdb37bdf5a3324831ef4891a`
- 原 APK 内 `assets/index.html` SHA-256：`733b1bf75a2695612ad47f834b29ef62959d8f0897ea5769176646db7cffa638`

## 文件来源

1. `project/app/src/main/assets/` 中的 7 个文件直接从原 1.0.1 签名 APK 原样提取，没有修改旧版功能或缓存名称。
2. `MainActivity.java`、`AndroidManifest.xml` 和 `res/values/strings.xml` 来自持久化保存的无后缀 1.0.1 源文件。另两个带 `(2)`、`(3)` 后缀的 Java 文件分别是 1.1.0、1.2.0，未用于本包。
3. `scripts/build_apk.sh` 是本次整理的可移植构建脚本，版本参数已设为 2 / 1.0.1；不是旧版绝对路径脚本的逐字副本。
4. `scripts/verify_apk_assets.py`、`tests/check_source.py`、`README_zh-CN.md` 和本说明为本次交付新增的验证与使用文档，不属于旧应用运行资源。
5. 旧版原始 README 未在现有文件中找到，因此没有重建或冒充旧说明。

## 验证边界

源码检查、完整 APK 重建、ZIP 条目内容比对和签名证书比对用于验证恢复结果。当前环境没有 Android 真机或模拟器，本次未重新执行设备启动、相机、系统导出或覆盖升级测试。
