# 食刻修复版 1.0.1 源代码

这是「食刻修复版」Android 1.0.1 的源码恢复包，包名 `app.shike.diet.fixed`，`versionCode=2`。包含原生 WebView 外壳、旧版 HTML/CSS/JavaScript、图标、离线资源、构建脚本和源码检查工具。

本包按旧版原始资料整理：`index.html` 等 7 个网页资源直接取自此前交付的签名 APK；`MainActivity.java`、`AndroidManifest.xml` 和应用名来自保存的 1.0.1 源文件变体。没有把 1.2.0 的新功能反向删除来冒充旧版。

> 不包含签名私钥、密码、Android SDK、APK 或编译产物。重新构建需使用自己的签名；新签名不能覆盖升级由此前其他证书签名的安装包。

## 目录

```text
Shike_1.0.1_Source/
├── project/app/src/main/
│   ├── AndroidManifest.xml          # versionCode 2 / versionName 1.0.1
│   ├── java/app/shike/diet/fixed/
│   │   └── MainActivity.java        # 1.0.1 原生外壳与可见启动诊断
│   ├── assets/
│   │   ├── index.html               # 旧版界面和全部业务逻辑
│   │   ├── manifest.json
│   │   ├── sw.js
│   │   └── icons/                   # 4 个 PWA 图标
│   └── res/                         # 食刻修复版应用名、样式和启动图标
├── scripts/
│   ├── build_apk.sh                 # 无 Gradle 的命令行构建
│   └── verify_apk_assets.py         # APK 与源码 assets 逐字节比对
├── tests/check_source.py            # 版本、页面、脚本与资源静态检查
└── reference/                       # 原始安装说明与恢复验证资料
```

## 构建环境

需要 Bash、Python 3、Node.js 18+、zip/unzip、JDK 17，以及：

- Android SDK Platform `android-35`
- Android SDK Build-Tools `35.0.0`

### 使用现有签名

```bash
cd Shike_1.0.1_Source
export ANDROID_SDK_ROOT=/你的路径/Android/Sdk
export SHIKE_KEYSTORE=/你的路径/my-release.jks
export SHIKE_KS_PASS='你的签名密码'
bash scripts/build_apk.sh
```

也可通过 `SHIKE_KEYSTORE_PASS_FILE` 指定密码文件。签名别名应为 `shikefixed`，输出为：

```text
build/shike-android-1.0.1-fixed.apk
```

如需改变输出目录，可设置 `BUILD_DIR`。如现有签名别名不同，请修改构建脚本中 `apksigner` 的 `--ks-key-alias`。

### 仅用于全新安装的本地签名

```bash
export ANDROID_SDK_ROOT=/你的路径/Android/Sdk
SHIKE_GENERATE_KEYSTORE=1 bash scripts/build_apk.sh
```

脚本会在 `keystore/` 生成新私钥和随机密码文件，请妥善保管，不要公开。

**签名兼容警告：** 原私钥未放入源码包。使用新签名构建的 APK 不能覆盖升级此前交付的 1.0.1，也不能直接覆盖 1.1.0/1.2.0。不要为处理签名冲突而直接卸载旧应用；卸载会清除本机记录，操作前请导出备份。

## 检查

```bash
python3 tests/check_source.py
bash -n scripts/build_apk.sh
```

构建后核对资源：

```bash
python3 scripts/verify_apk_assets.py build/shike-android-1.0.1-fixed.apk
```

如需核对旧版包信息与签名：

```bash
$ANDROID_SDK_ROOT/build-tools/35.0.0/aapt dump badging build/shike-android-1.0.1-fixed.apk
$ANDROID_SDK_ROOT/build-tools/35.0.0/apksigner verify --verbose --print-certs build/shike-android-1.0.1-fixed.apk
```

## 旧版边界

- 这是 1.0.1 修复版，不包含 1.1.0 的视觉升级，也不包含 1.2.0 的全局食物库和拍照识别优化。
- 本机存储键为 `shike-food-energy-ledger-v1`。卸载或清除应用数据会删除记录，请定期导出 JSON/CSV。
- USDA 在线搜索需要网络，`DEMO_KEY` 可能有限额；照片相关服务需按旧版页面说明配置。
- 单目照片不能保证绝对克重或识别准确率；饮食热量为估算，不用于医疗诊断或处方。
- 原 APK 已完成包信息与签名检查；本次源码包会另行进行重建和资源一致性检查，但不代表重新完成 Android 真机测试。
